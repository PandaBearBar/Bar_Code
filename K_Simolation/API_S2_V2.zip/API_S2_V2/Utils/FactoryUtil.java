package K_Simolation.API_S2_V2.Utils;

import K_Simolation.API_S2_V2.Beans.Person;

public class FactoryUtil {
    public static Person initPerson(){
        return new Person();
    }
}
